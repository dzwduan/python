import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow.python.ops import array_ops
from tensorflow.python.ops.math_ops import sigmoid
from tensorflow.python.ops.math_ops import tanh
from tensorflow.contrib.rnn.python.ops import core_rnn_cell

class BatchNormLSTMCell(core_rnn_cell.RNNCell):
	def __init__(self,num_units,is_training=False,forget_bias=1.0,activation=tanh,reuse=None):
	    self._num_units=num_units
		self._is_training=is_training
		self._forget_bias=forget_bias
		self._activation=activation
		self._reuse=reuse
		
		@property
		def state_size(self):
			return core_rnn_cell.LSTMStateTuple(self._num_units,self._num_units) #？？？？？？
		
		def output_size(self)：
			return self._num_units
		
		def _call_(self,inputs,state,scope=None):
			with tf.variable_scope(scope or type(self).__name__,reuse=self._reuse)：#------why
			    c,h=state
				input_size=inputs.get_shape().as_list()[1]
				w_xh=tf.get_variable('w_xh',[input_size,4*self._num_units],initializer=bn_lstm_identity_initializer(0.95))#输入层
				w_hh=tf.get_variable('w_hh',[input_num_units,，4*self._num_units],initializr=bn_lstm_identity_initializer(0.95))#隐藏层
				bias=tf.get_variable('bias',[4*self._num_units])#-----why multiply4
				xh=tf.matmul(inputs,w_xh)
				hh=tf.matmul(h,w_hh)  #两个乘法？？
				
				hidden=bn_xh+bn_hh+bias
				#i=
				i,j ,f ,o=array_ops.split(value=hidden,num_or_size_splits=4,axis=1)
				