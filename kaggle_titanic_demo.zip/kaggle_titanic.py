import tensorflow as tf
import os

#变量初始化
W=tf.Variable(tf.zeros([5,1]),name="weights")
b=tf.Variable(0.,name="bias")

def combine_inputs(X):
	return tf.matmul(X,W)+b

#用sigmoid函数得到0/1
def inference(X):
	return tf.sigmoid(combine_inputs(X))
	
def loss(X,Y):
	return tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(combine_inputs(X),Y))



def read_csv(batch_size,file_name,record_defaults):
	filename_queue=tf.train.string_input_producer([os.path.dirname(_file_)+"/"+file_name])
	#os.path.dirname(__file__)返回脚本的路径
	#tf.train.string_input_producer函数需要传入一个文件名list，系统会自动将它转为一个文件名队列。
	#filename_queue是一个文件名队列
	reader=tf.TextLineReader(skip_header_lines=1)
	#按行读取
	#skip_header_lines：可选int 默认为0.从每个文件的开头跳过的行数。
	#reader是按行读取的数据
	key, value=reader.read(filename_queue)
	#tf.TextLineReader().read()返回读取的键值对
	#key,value是键值对
	
	#decode_csv会将字符串(文本行)转换到具有指定默认值的由张量构成的元组中
	#它还会为每一列设置数据类型是
	#decoded是record_defaults类型的元组
	decoded=tf.decode_csv(value,record_defaults=record_defaults)
	#读取一个文件并加载一个张量中的batch_size行
	return tf.train.shuffle_batch(decoded, #张量
								  batch_size=batch_size #出队列的新的批尺寸
								  capacity=batch_size*50  #队列中元素最大数量
								  min_after_dequeue=batch_size)#出队后队列中的最小数字元素
	#返回张量类型的列表或字典
	

def inputs():
	passenger_id, survived, pclass, name, sex, age, sibsp, parch, ticket, fare, cabin, embarked = \
        read_csv(100, "train.csv", [[0.0], [0.0], [0], [""], [""], [0.0], [0.0], [0.0], [""], [0.0], [""], [""]])
	#转换属性数据
	is_first_class=tf.to_float(tf.equal(pclass,[1]))
	is_second_class = tf.to_float(tf.equal(pclass, [2]))
    is_third_class = tf.to_float(tf.equal(pclass, [3]))
	#tf.equal返回bool值,这边转换为0/1
	gender=tf.to_float(tf.equal(sex,["female"]))
	#最终将所有特征排列在一个矩阵中，使其每行对应一个样本，
	#每列对应一个特征
	features=tf.transpose(tf.pack([is_first_class, is_second_class, is_third_class, gender, age]))
	survived=tf.reshape(survived,[100,1])
	return features,survived

#训练数据	
def train(total_loss):
	learning_rate=0.01
	return tf.train.GradientDescentOptimizer(learning_rate).minimize(total_loss)
	
#评估数据
def evaluate(sess,X,Y):
	#predicted只有0或1两个值
    predicted=tf.cast(inference(X)>0.5,tf.float32)
	print (sess.run(tf.reduce_mean(tf.cast(tf.equal(predicted,Y),float32))))
#求转换的数据的均值

#在session中启动图表，设置样板
with tf.Session() as sess:
	tf.global_bariables_initializer().run()
	#----------------
	X,Y=inputs()
    #----------------
	total_loss=loss(X,Y)
#	该类实现一个简单的机制来协调一组线程的终止
	coord=tf.train.Coordinator()
	train_op=train(total_loss)
#   启动图中所有的线程	
	coord=tf.train.start_queue_runners(sess=sess,coord=coord)
    training_steps=1000
	for step in range(training_steps):
		sess.run([train_op])
		if step%10==0:
			print("loss:",sess.run([total_loss])
	evaluate(sess,X,Y)
	import time
	time.sleep(5)
	coord.request_stop()  #要求线程停止
    coord.join(threads)   #等待线程停止
    sess.close()














	
	
	
	