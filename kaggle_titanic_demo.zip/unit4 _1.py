# -*- coding: utf-8 -*-
"""
Created on Sat Jun  3 14:57:48 2017

@author: DZW
"""

import tensorflow as tf
#定义全局变量
W=tf.Variable(tf.zeros([2,1]),name="weights") #???? why2,1
b=tf.Variable(0.,name="bias")

def inference(X):
	return tf.matmul(X,W)+b

def loss(X,Y):  #loss为平方差的和
	Y_predicted=inference(X)
	return tf.reduce_sum(tf.squared_difference(Y,Y_predicted)) 

def inputs():
	 # Data from http://people.sc.fsu.edu/~jburkardt/datasets/regression/x09.txt
    weight_age = [[84, 46], [73, 20], [65, 52], [70, 30], [76, 57], [69, 25], [63, 28], [72, 36], [79, 57], [75, 44], [27, 24], [89, 31], [65, 52], [57, 23], [59, 60], [69, 48], [60, 34], [79, 51], [75, 50], [82, 34], [59, 46], [67, 23], [85, 37], [55, 40], [63, 30]]
    blood_fat_content = [354, 190, 405, 263, 451, 302, 288, 385, 402, 365, 209, 290, 346, 254, 395, 434, 220, 374, 308, 220, 311, 181, 274, 303, 244]
	#类型转换
    return tf.to_float(weight_age),tf.to_float(blood_fat_content)

def train(total_loss):  #训练数据，用梯度下降法
	learning_rate=0.0000001
	return tf.train.GradientDescentOptimizer(learning_rate).minimize(total_loss)

def evaluate(sess,X,Y):  #评估数据
	print (sess.run(inference([[80.,25.]])))    #why2个中括号
	print (sess.run(inference([[65.,25.]])))

with tf.Session() as sess:
	tf.global_variables_initializer()
	X,Y=inputs()
	total_loss=loss(X,Y)
	train_op=train(total_loss)
	
	coord=tf.train.Coordinator()  #该类实现一个简单的机制来协调一组线程的终止。
	threads=tf.train.start_queue_runners(sess=sess, coord=coord) #启动所有的线程
	
	training_steps=1000
	for step in range(training_steps):
		sess.run([train_op])  #为什么带中括号
		if step%10==0:
			print ("loss:",sess.run([total_loss]))
	
	evaluate(sess,X,Y)  #看不懂
	coord.requset_stop() #要求线程停止
	coord.join(threads)  #等待进程停止
	sess.close()           #不是多余吗？
	
	
